#ifndef _lua_reset_h
#define _lua_reset_h

#include "../common/lua_common.h"

int lua_git_reset(lua_State *L);

#endif
