#ifndef _lua_diff_help_h
#define _lua_diff_help_h

#include "../common/lua_common.h"

int lua_diff_format_init(lua_State *L);
int lua_diff_stats_format_init(lua_State *L);

#endif
