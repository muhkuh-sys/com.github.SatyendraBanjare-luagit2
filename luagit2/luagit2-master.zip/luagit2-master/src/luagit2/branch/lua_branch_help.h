#ifndef _lua_branch_help
#define _lua_branch_help

#include "../common/lua_common.h"

int get_type_GIT_BRANCH_LOCAL(lua_State *L);
int get_type_GIT_BRANCH_REMOTE(lua_State *L);

#endif
