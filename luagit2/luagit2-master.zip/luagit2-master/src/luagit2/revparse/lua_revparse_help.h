#ifndef _lua_revparse_help_h
#define _lua_revparse_help_h

#include "../common/lua_common.h"

int lua_git_revspec_from(lua_State *L);
int lua_git_revspec_to(lua_State *L);

#endif
