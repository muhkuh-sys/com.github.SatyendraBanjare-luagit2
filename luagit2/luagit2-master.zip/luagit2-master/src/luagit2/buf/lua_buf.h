#ifndef _lua_buf_h
#define _lua_buf_h

#include "../common/lua_common.h"

int lua_git_buf_set_str(lua_State *L);
int lua_git_buf_free(lua_State *L);

#endif
