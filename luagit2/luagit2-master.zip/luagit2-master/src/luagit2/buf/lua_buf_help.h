#ifndef _lua_buf_help_h
#define _lua_buf_help_h

#include "../common/lua_common.h"

int lua_git_buf_details(lua_State *L);

#endif
