#ifndef _lua_blame_help_h
#define _lua_blame_help_h

#include "../common/lua_common.h"

int lua_blame_hunk_signature(lua_State *L);
int lua_blame_hunk_commit_id(lua_State *L);

#endif
