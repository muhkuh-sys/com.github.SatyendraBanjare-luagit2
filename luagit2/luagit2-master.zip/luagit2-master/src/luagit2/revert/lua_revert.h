#ifndef _lua_revert_h
#define _lua_revert_h

#include "../common/lua_common.h"

int lua_git_revert(lua_State *L);

#endif
