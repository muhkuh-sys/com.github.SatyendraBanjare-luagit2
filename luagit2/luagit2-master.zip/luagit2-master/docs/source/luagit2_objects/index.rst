########################
Luagit2 Userdata Objects
########################

This section contains information on used luagit2 objects in luagit2 API's functions.

.. toctree::
   :maxdepth: 2
   :numbered:
   
   luagit2_objects