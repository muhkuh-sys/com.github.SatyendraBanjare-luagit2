########
Examples
########

This section contains explaination on examples provided in luagit2.

.. toctree::
   :maxdepth: 2
   :numbered:
   
   add_to_index
   blame_file
   clone
   diff_files
   init_and_make_initial_commit
