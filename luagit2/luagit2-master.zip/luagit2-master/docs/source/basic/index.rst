################### 
Basic Documentation 
################### 
 
This section contains explaination on Luagit2 API. 
 
.. toctree::
   :maxdepth: 2
   :numbered: 
    
   annotated 
   blame
   blob
   branch
   buf
   checkout
   clone
   commit
   config
   cred
   describe
   diff
   graph
   ignore
   index_module
   libgit 
   note
   object
   odb
   reference
   reflog
   repository
   reset
   revert
   revparse
   revwalk
   signature
   status
   tag
   tree
